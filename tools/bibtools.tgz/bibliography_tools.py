
import sys
import json
import re
import argparse

import bibtexparser
from bibtexparser.bparser import BibTexParser
from bibtexparser.customization import *
from bibtexparser.customization import homogenize_latex_encoding
from bibtexparser.customization import convert_to_unicode
from bibtexparser.bwriter import BibTexWriter


def customizations(record):
    """Use some functions delivered by the library

    :param record: a record
    :returns: -- customized record
    """
    record = type(record)
    # parser author into a list
    record = author(record)
    record = homogenize_latex_encoding(record)

    # parser journal name into {'name': original name, 'ID': No space name}
    # record = journal(record)

    # find the link and parser into [{'url': 'https://xxx', 'anchor': 'doi'}]
    # record = link(record)
    # record = doi(record)

    
    # record = editor(record)
    # record = keyword(record)
    # record = page_double_hyphen(record)

    return record


def process_title(title):
    title = re.sub(r'[{}]', '', title)
    
    def replace_upper(match):
        word = match.group()
        upper_count = sum(1 for c in word if c.isupper())
        if upper_count >= 2:
            return ''.join(['{' + c + '}' if c.isupper() else c for c in word])
        else:
            return word
    
    title = re.sub(r'\b\w+\b', replace_upper, title)
    
    if len(title) > 0 and title[0].isalpha():
        title = '{' + title[0] + '}' + title[1:]
    
    def surround_after_colon(match):
        colon = match.group(1)
        space = match.group(2)
        char = match.group(3)
        return f"{colon}{space}{{{char}}}"
    
    title = re.sub(r'(:)(\s*)(\w)', surround_after_colon, title)
    
    return title

def journal_abbreviator(journal_list_path:str, bib_file:str):

    output_bib_file = bib_file.split('/')[-1].replace('.bib', '_abb.bib')

    with open(journal_list_path) as jour:
        journal_database = json.load(jour)
        journal_database = {k.lower(): v for k, v in journal_database.items()}
    
    with open(bib_file) as bibtex_file:
        parser = BibTexParser()
        parser.customization = customizations
        bib_database = bibtexparser.load(bibtex_file, parser=parser)

    for entry in bib_database.entries:

        try:
            ori_title = entry['title']
            proc_title = process_title(ori_title)
            entry['title'] = proc_title
        except:
            print(f"Why there is not title?")
        

        try:
            journal_name = entry["journal"].lower()
            abbreviation_name = journal_database[journal_name]
            # print(f"- Original journal name(lower):{journal_name}.")
            # print(f"->Abbreviated journal name:{abbreviation_name}")
            # print(f"Author:{entry['author']}")
        except KeyError as err:
            # print(err)
            print(f"No journal name was found for #{entry['title']}#, maybe it's a book or web?\n")


        try:

            entry["journal"] = abbreviation_name
            author_list = entry['author']
            # print(f"- Original author:{author_list}")
            new_author = []
            for auth in author_list:
                last_name = auth.split(',')[0].strip()
                first_name = auth.split(',')[1:]
                abbreviation_1st_name = [f"{na.strip()[0].upper()}." for na in first_name]
                # print(f"-> first name:{first_name}\n-> abbreviation first name:{abbreviation_1st_name}")
                comb_name_list = [last_name] + abbreviation_1st_name

                abbreviation_full_name = ', '.join(comb_name_list)
                # print(f"abbreviation_full_name:{abbreviation_full_name}")

                new_author.append(abbreviation_full_name)

            full_name_list = ' and '.join(new_author)
            # print(f"full_name_list{full_name_list}")
            entry["author"] = full_name_list 
            # print(entry["author"])
        
        except:
            print("Why there is no author?")


    writer = BibTexWriter()
    writer.indent = '    ' 
    with open(output_bib_file, 'w') as bibfile:
        bibfile.write(writer.write(bib_database))

    print(f"Clean up the {bib_file} to {output_bib_file}!")
    

if __name__ == '__main__':
    # Create an ArgumentParser object
    parser = argparse.ArgumentParser(description="Journal abbreviation")

    # Add two arguments: one for the journal name database, and one for the bibliography file
    parser.add_argument('--db',
                        type=str,
                        required=True,
                        help="Path to the journal name database (JSON format)")

    parser.add_argument('--bib',
                        type=str,
                        required=True,
                        help="Path to the bibliography file (BibTeX format)")

    # Parse the command-line arguments
    args = parser.parse_args()

    journal_db = args.db
    bib_file = args.bib
    journal_abbreviator(journal_db, bib_file)